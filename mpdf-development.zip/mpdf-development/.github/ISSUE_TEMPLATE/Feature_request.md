---
name: Feature request 🚀
about: I would like to have a new functionality added
---

# Feature request

<!-- Please describe the new functionality as best as you can. -->
