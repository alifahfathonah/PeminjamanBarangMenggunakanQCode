<?php

namespace Mpdf\Exception;

class FontException extends \Mpdf\MpdfException
{

}
