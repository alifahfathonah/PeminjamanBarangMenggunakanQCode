<?php

namespace Mpdf\Tag;

class Address extends BlockTag
{


}
